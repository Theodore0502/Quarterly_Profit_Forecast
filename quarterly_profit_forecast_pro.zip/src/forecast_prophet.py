# -*- coding: utf-8 -*-
import pandas as pd, os
from prophet import Prophet

INP = "out/quarterly_profit.csv"
OUT = "out/forecast_prophet.csv"

def main():
    if not os.path.exists(INP):
        raise SystemExit("❌ Thiếu out/quarterly_profit.csv — hãy chạy prepare_data trước.")
    df = pd.read_csv(INP, parse_dates=["date"]).rename(columns={"date":"ds","profit":"y"})
    m = Prophet(seasonality_mode="additive", yearly_seasonality=True)
    m.fit(df)
    future = m.make_future_dataframe(periods=4, freq="QE-DEC")
    fc = m.predict(future)[["ds","yhat","yhat_lower","yhat_upper"]]
    fc = fc.merge(df, on="ds", how="left")
    fc.to_csv(OUT, index=False)
    print("✅", OUT)

if __name__ == "__main__":
    main()
