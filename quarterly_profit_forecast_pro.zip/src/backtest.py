# -*- coding: utf-8 -*-
import pandas as pd, numpy as np, os
from prophet import Prophet
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, mean_absolute_error

def backtest_prophet(df, initial_quarters=12, step_quarters=1, horizon_quarters=4):
    rows=[]
    n=len(df)
    for start in range(initial_quarters, n - horizon_quarters, step_quarters):
        train = df.iloc[:start]; test  = df.iloc[start:start+horizon_quarters]
        m=Prophet(yearly_seasonality=True, seasonality_mode="additive").fit(train)
        future=m.make_future_dataframe(periods=horizon_quarters, freq="QE-DEC")
        fc=m.predict(future).tail(horizon_quarters)
        rmse=np.sqrt(mean_squared_error(test["y"], fc["yhat"]))
        mae = mean_absolute_error(test["y"], fc["yhat"])
        rows.append({"cutoff":train["ds"].max().date(),"rmse":rmse,"mae":mae})
    return pd.DataFrame(rows)

def backtest_regression(df, X_cols, initial_quarters=12, step_quarters=1, horizon_quarters=4):
    rows=[]; n=len(df)
    for start in range(initial_quarters, n - horizon_quarters, step_quarters):
        tr = df.iloc[:start]; te = df.iloc[start:start+horizon_quarters]
        model=LinearRegression().fit(tr[X_cols], tr["profit"])
        pred=model.predict(te[X_cols])
        rmse=np.sqrt(mean_squared_error(te["profit"], pred))
        mae = mean_absolute_error(te["profit"], pred)
        rows.append({"cutoff":tr["date"].max().date(),"rmse":rmse,"mae":mae,"features":"+".join(X_cols)})
    return pd.DataFrame(rows)

def main():
    if not os.path.exists("out/quarterly_profit.csv") or not os.path.exists("out/processed_quarterly.csv"):
        raise SystemExit("❌ Thiếu input: hãy chạy prepare_data trước.")
    dfp = pd.read_csv("out/quarterly_profit.csv", parse_dates=["date"]).rename(columns={"date":"ds","profit":"y"})
    bp = backtest_prophet(dfp)
    bp.to_csv("out/backtest_prophet.csv", index=False)
    dfr = pd.read_csv("out/processed_quarterly.csv", parse_dates=["date"]).sort_values("date")
    X_cols = [c for c in ["revenue","marketing_cost","cpi"] if c in dfr.columns]
    br = backtest_regression(dfr, X_cols=X_cols)
    br.to_csv("out/backtest_regression.csv", index=False)
    print("✅ out/backtest_prophet.csv, out/backtest_regression.csv")

if __name__ == "__main__":
    main()
