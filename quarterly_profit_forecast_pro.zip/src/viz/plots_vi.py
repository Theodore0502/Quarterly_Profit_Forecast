# -*- coding: utf-8 -*-
import pandas as pd, matplotlib.pyplot as plt
from pathlib import Path
Path("out/plots").mkdir(parents=True, exist_ok=True)
plt.rcParams["font.family"] = ["Segoe UI","Arial"]
plt.rcParams["axes.unicode_minus"] = False

fc = pd.read_csv("out/forecast_prophet.csv", parse_dates=["ds"])
plt.figure()
past = fc.dropna(subset=["y"])
plt.plot(past["ds"], past["y"], label="Thực tế")
plt.plot(fc["ds"], fc["yhat"], label="Dự báo")
plt.fill_between(fc["ds"], fc["yhat_lower"], fc["yhat_upper"], alpha=0.2, label="Khoảng tin cậy")
plt.title("Lợi nhuận theo quý — Thực tế vs Dự báo (Prophet)")
plt.xlabel("Thời gian (quý)"); plt.ylabel("Lợi nhuận"); plt.legend()
plt.tight_layout(); plt.savefig("out/plots/01_thuc_te_vs_du_bao_prophet.png", dpi=160)

oof = pd.read_csv("out/regression_oof_predictions.csv", parse_dates=["date"])
plt.figure()
plt.plot(oof["date"], oof["y_true"], label="Lợi nhuận thực tế (y)")
plt.plot(oof["date"], oof["y_pred"], label="Dự đoán OOF (y_pred)")
plt.title("Hồi quy tuyến tính — Dự đoán OOF vs Thực tế")
plt.xlabel("Thời gian (quý)"); plt.ylabel("Lợi nhuận"); plt.legend()
plt.tight_layout(); plt.savefig("out/plots/02_hoi_quy_oof_vs_thuc_te.png", dpi=160)

print("✅ Đã lưu ảnh tại out/plots/")
