# -*- coding: utf-8 -*-
import subprocess, sys
def run_all():
    py = sys.executable
    subprocess.check_call([py, "src/prepare_data.py"])
    subprocess.check_call([py, "src/forecast_prophet.py"])
    subprocess.check_call([py, "src/regression_sklearn.py"])
    subprocess.check_call([py, "src/backtest.py"])
    subprocess.check_call([py, "src/viz/plots_vi.py"])
if __name__ == "__main__":
    run_all()
