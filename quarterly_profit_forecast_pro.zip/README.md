# quarterly_profit_forecast_pro (VI) — Bản nâng cấp
Dùng được với 2 dataset bạn có. Chạy một lệnh: `python main.py`.
Kết quả chính: forecast 4 quý, hồi quy (OOF), backtest, PNG tiếng Việt, union cho Power BI.
