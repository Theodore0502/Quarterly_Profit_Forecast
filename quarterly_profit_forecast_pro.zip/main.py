# -*- coding: utf-8 -*-
import os, sys, subprocess, pandas as pd
from pathlib import Path
OUT = Path("out")
def run(cmd): print(">>"," ".join(cmd)); subprocess.check_call(cmd)
def ensure_data():
    if not (Path("data/Apple_DB.csv").exists() or Path("data/Data for Training - Apple DB - Accumulated Statement.csv").exists()):
        raise SystemExit("❌ Đặt CSV vào thư mục data/ rồi chạy lại.")
def build_union_for_powerbi():
    OUT.joinpath("powerbi").mkdir(parents=True, exist_ok=True)
    fc = pd.read_csv(OUT/"forecast_prophet.csv", parse_dates=["ds"])
    fc_prophet = fc.rename(columns={"ds":"date","y":"actual","yhat":"pred"}); fc_prophet["model"]="Prophet"
    reg = pd.read_csv(OUT/"regression_oof_predictions.csv", parse_dates=["date"])
    reg2 = reg.rename(columns={"y_true":"actual","y_pred":"pred"}); reg2["model"]="LinearRegression-OOF"
    union = pd.concat([fc_prophet[["date","actual","pred","model"]], reg2[["date","actual","pred","model"]]], ignore_index=True)
    union.sort_values("date").to_csv(OUT/"powerbi"/"ForecastUnion.csv", index=False)
def main():
    ensure_data()
    py = sys.executable
    run([py, "src/prepare_data.py"])
    run([py, "src/forecast_prophet.py"])
    run([py, "src/regression_sklearn.py"])
    run([py, "src/backtest.py"])
    run([py, "src/viz/plots_vi.py"])
    build_union_for_powerbi()
    fc = pd.read_csv(OUT/"forecast_prophet.csv", parse_dates=["ds"])
    fut = fc[fc["y"].isna()].head(4)[["ds","yhat","yhat_lower","yhat_upper"]]
    print("\n==== 4 QUÝ DỰ BÁO (Prophet) ===="); print(fut.to_string(index=False))
    print("\n✅ Xong. Xem thư mục out/")
if __name__ == "__main__":
    try: main()
    except subprocess.CalledProcessError as e: raise SystemExit(f"❌ Lỗi khi chạy: {e}")
